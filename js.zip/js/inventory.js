import { db } from "./firebase.js";

import {
 collection,
 getDocs
}
from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

const categoryContainer =
document.getElementById("categories");

async function loadCategories() {

    const snapshot =
    await getDocs(
        collection(
            db,
            "inventory_categories"
        )
    );

    snapshot.forEach(doc => {

        const data = doc.data();

        categoryContainer.innerHTML += `
        
        <div
        class="bg-white rounded-xl p-4 mb-3 shadow">

            <h2 class="font-semibold">

                ${data.name}

            </h2>

        </div>
        
        `;

    });

}

loadCategories();